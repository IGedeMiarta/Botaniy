
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="page-title m-0"><?php echo e($title); ?></h4>
                    </div>
                    <div class="col-md-4">
                        <div class="float-right d-none d-md-block">
                            <div class="btn-group btn-group-toggle text-center" data-toggle="buttons">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-qrcode mr-2"></i> QR-Code
                                </button>
                                <button class="btn btn-danger" type="button">
                                    <i class="fas fa-file-pdf mr-2"></i> PDF
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- end page-title-box -->
        </div>
    </div>
    <!-- end page title -->
    <div class="card">
        <div class="card-body">
            <table id="datatable" class="table table-bordered dt-responsive nowrap"
                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                    <tr>
                        <th width="10px">No</th>
                        <th>Gambar</th>
                        <th>Nama</th>
                        <th>Jenis</th>
                        <th>Khasiat</th>
                        <th>Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tanaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><img src="<?php echo e(asset($t->gambar)); ?>" alt="img-<?php echo e($t->nama); ?>" style="max-width: 100px">
                            </td>
                            <td><?php echo e($t->nama); ?></td>
                            <td><?php echo e($t->jenis->nama); ?></td>
                            <td><?php echo e($t->khasiat); ?></td>
                            <td><?php echo e('Rp ' . number_format($t->harga, 2, ',', '.')); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WEB\Botaniy\resources\views/laporan/tanaman.blade.php ENDPATH**/ ?>