  <footer class="footer">
      © 2022 Botany <span class="d-none d-md-inline-block"> - Crafted with <i
              class="mdi mdi-heart text-danger"></i></span>
  </footer>
<?php /**PATH F:\WEB\Botaniy\resources\views/master/dashboard/footer.blade.php ENDPATH**/ ?>