
<?php $__env->startSection('content'); ?>
    <!-- start navbar -->
    <?php echo $__env->make('master.landing.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- start hero -->
    <?php echo $__env->make('master.landing.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end hero -->

    <!-- start solution -->
    <?php echo $__env->make('master.landing.jenis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end solution -->
    <?php echo $__env->make('master.landing.catalog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.landing.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WEB\Botaniy\resources\views/master/landing/master.blade.php ENDPATH**/ ?>