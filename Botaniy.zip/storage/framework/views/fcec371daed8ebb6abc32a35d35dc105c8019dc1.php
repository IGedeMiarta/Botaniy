<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Botaniy</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Premium Bootstrap 5 Template" />
    <meta name="keywords" content="bootstrap 5, premium, marketing, multipurpose" />
    <meta content="Themesdesign" name="author" />

    <!-- favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('land')); ?>/images/favicon.ico" />

    <!-- tinyslider -->
    <link rel="stylesheet" href="<?php echo e(asset('land')); ?>/css/tiny-slider.css" />

    <!-- css -->
    <link href="<?php echo e(asset('land')); ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('land')); ?>/css/style.min.css" rel="stylesheet" type="text/css" />


    
    <link rel="stylesheet" href="<?php echo e(asset('')); ?> sweetalert2.min.css">
</head>

<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="67">
   
    <!-- end navbar -->
    <?php if(session()->has('success')): ?>
        <div class="success-info" data-msg="<?php echo e(session('success')); ?>"></div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
        <div class="error-info" data-msg="<?php echo e(session('error')); ?>"></div>
    <?php endif; ?>
    
    <?php echo $__env->yieldContent('content'); ?>

    <!-- start footer -->
    <?php echo $__env->make('master.landing.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end footer -->

    


    <!-- Modal -->
    <?php echo $__env->make('login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end modal -->

    <script src="<?php echo e(asset('land')); ?>/js/bootstrap.bundle.min.js"></script>

    <!-- feather icon -->
    <script src="<?php echo e(asset('land')); ?>/js/feather.js"></script>

    <!-- client-slider -->
    <script src="<?php echo e(asset('land')); ?>/js/tiny-slider.js"></script>
    <script src="<?php echo e(asset('land')); ?>/js/tiny.init.js"></script>

    <!-- moving letter -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
    <script src="<?php echo e(asset('land')); ?>/js/text-animation.init.js"></script>

    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('')); ?>sweetalert/sweetalert2.all.js"></script>
    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        var success = $('.success-info').data('msg');
        var error = $('.error-info').data('msg');
        if (error) {
            Toast.fire({
                icon: 'error',
                title: error
            })
        }
        if (success) {
            Toast.fire({
                icon: 'success',
                title: success
            })
        }
    </script>
    <?php echo $__env->yieldPushContent('script'); ?>
    <script src="<?php echo e(asset('land')); ?>/js/app.js"></script>
</body>

</html>
<?php /**PATH F:\WEB\Botaniy\resources\views/master/landing/index.blade.php ENDPATH**/ ?>